# RadioCalico Project

## Stack
- Frontend/web server: Express.js
- Backend database: SQLite + Flask

## Development Server
- Start command: `npm start`
- **Never run `npm start` in the foreground** — it will block. Run in the background if a restart is needed.
- Assume the server is already running unless told otherwise.
